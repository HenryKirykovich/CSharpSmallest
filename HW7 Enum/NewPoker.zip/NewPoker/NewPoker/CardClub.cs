﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    public class CardClub : SuperCard
    {
        private Suit _cardssuit = Suit.Club;
        public override Suit CardsSuit
        {
            get { return _cardssuit; }
        }
        public CardClub(Rank newRank)
        {
            cardsRank = newRank;
        }

        public override void Display()
        {
            // Code to draw a club card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(cardsRank + " of " + _cardssuit + "s ♣");
            Console.ResetColor();
        }
    }
}
