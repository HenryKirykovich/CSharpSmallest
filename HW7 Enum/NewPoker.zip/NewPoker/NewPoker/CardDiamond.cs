﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    internal class CardDiamond : SuperCard
    {
        private Suit _cardssuit = Suit.Diamond;
        public override Suit CardsSuit
        {
            get { return _cardssuit; }
        }

        public CardDiamond(Rank newRank)
        {
            cardsRank = newRank;
        }

        public override void Display()
        {
            // Code to draw a diamond card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(cardsRank + " of " + _cardssuit + "s ♦");
            Console.ResetColor();
        }
    }
}
