﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    internal class CardHeart : SuperCard
    {
        private Suit _cardssuit = Suit.Heart;
        public override Suit CardsSuit
        {
            get { return _cardssuit; }
        }

        public CardHeart(Rank newRank)
        {
            cardsRank = newRank;
        }
        public override void Display()
        {
            // Code to draw a heart card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(cardsRank + " of " + _cardssuit + "s ♥");
            Console.ResetColor();
        }
    }
}
