﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    internal class CardSet
    {
        Random ranNum = new Random();

        public SuperCard[] TheDeckOfCards = new SuperCard[52];

        public CardSet()
        {
            int index = 0;  // point to all 52 positions
            Rank rankIndex = Rank.Deuce;

            while (index < TheDeckOfCards.Length)
            {
                TheDeckOfCards[index++] = new CardSpade(rankIndex);
                TheDeckOfCards[index++] = new CardHeart(rankIndex);
                TheDeckOfCards[index++] = new CardClub(rankIndex);
                TheDeckOfCards[index++] = new CardDiamond(rankIndex++);
            }
        }

        public SuperCard[] GetCards(int howManyCards)
        {
            SuperCard[] handArray = new SuperCard[howManyCards];
            int ran; // holds random number 0-51
            for (int i = 0; i < howManyCards; i++)  // create as many cards in the hand as asked for
            {
                bool success = false;
                while (!success)  // sit in this while loop until we find a card that is available.
                {
                    ran = ranNum.Next(0, 52);
                    if (TheDeckOfCards[ran].inplay == false)
                    {
                        handArray[i] = TheDeckOfCards[ran];
                        TheDeckOfCards[ran].inplay = true;
                        success = true;
                    }
                }
            }
            return handArray;
        }

        internal void ResetUsage()
        {
            {
                foreach (SuperCard item in TheDeckOfCards)
                {
                    item.inplay = false;
                }
            }
        }

        internal SuperCard GetOneCard()
        {
            int ran = 0; // holds random number 0-51
            bool success = false;
            while (!success)
            {
                ran = ranNum.Next(0, 52);
                if (TheDeckOfCards[ran].inplay == false)
                {
                    TheDeckOfCards[ran].inplay = true;
                    success = true;
                }
            }
            return TheDeckOfCards[ran];
        }
    }
}
