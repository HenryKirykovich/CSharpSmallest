﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    internal class CardSpade : SuperCard
    {
        private Suit _cardssuit = Suit.Spade;
        public override Suit CardsSuit
        {
            get { return _cardssuit; }
        }

        public CardSpade(Rank newRank)
        {
            cardsRank = newRank;
        }

        public override void Display()
        {
            // Code to draw a Spade card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(cardsRank + " of " + _cardssuit + "s ♠");
            Console.ResetColor();
        }
    }
}
