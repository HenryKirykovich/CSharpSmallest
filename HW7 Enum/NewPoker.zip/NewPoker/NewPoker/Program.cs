﻿

namespace NewPoker
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CardSet myDeck = new CardSet();
            int howManyCards = 2;  // allow the number of cards in a hand to be a variable.  what happens if you make this 26?
            int balance = 3;  // start with $10

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Clear();

            Console.WriteLine("Welcome to the Poker Game.");
            Console.WriteLine("You have $" + balance + " and each bet will be $1.");

            while (balance != 0) // play until they have no money left
            {
                myDeck.ResetUsage(); // put all previously used cards back to an available state
                SuperCard[] computerHand = myDeck.GetCards(howManyCards);
                SuperCard[] playersHand = myDeck.GetCards(howManyCards);

                Array.Sort(computerHand);  // add these 4 lines here
                Array.Reverse(computerHand);
                Array.Sort(playersHand);
                Array.Reverse(playersHand);

                DisplayHands(computerHand, playersHand);  // show player the cards

                PlayerDrawsOne(playersHand, myDeck);  // allow player to replace 1 card
                ComputerDrawsOne(computerHand, myDeck);  // let the computer replace one too

                Array.Sort(playersHand);
                Array.Reverse(playersHand);

                DisplayHands(computerHand, playersHand);  // show player the revised cards




                bool won = CompareHands(computerHand, playersHand);

                if (won)
                {
                    balance = balance + 1;
                    Console.WriteLine("You won.");
                }
                else
                {
                    balance = balance - 1;
                    Console.WriteLine("You lost.");
                }

     
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("You have $" + balance + "   Push Enter for another Hand");
                Console.ReadLine();
                Console.Clear();

            }
            Console.WriteLine();
            Console.WriteLine("sorry, you are out of money");
        }

        private static void ComputerDrawsOne(SuperCard[] computerHand, CardSet myDeck)
        {
            if (Flush(computerHand) )  // or straight
            {
                return;
            }
            int lowCard = 0;
            int valCard = (int)(computerHand[0].cardsRank);
            for (int i = 1; i < computerHand.Length; i++)
            {
                if (valCard > (int)(computerHand[i].cardsRank))
                {
                    lowCard = i;
                    valCard = (int)(computerHand[i].cardsRank);
                }
            }
            if (valCard < 7)  // Rank is off by 1, e.g a duece is a 1 in the enum
            {
                computerHand[lowCard] = myDeck.GetOneCard();
            }
        }

        private static void PlayerDrawsOne(SuperCard[] playersHand, CardSet myDeck)
        {
            // let user reaplace one of the first 5 cards
            bool isValidInt = false;
            int whichCard = 0;
            while (!isValidInt)
            {
                Console.WriteLine("which card would you like to draw and replace?");
                Console.WriteLine("0 for none, else 1,2,3, ...");
                isValidInt = int.TryParse(Console.ReadLine(), out whichCard);
            }
            if (whichCard > 0 && whichCard < 6) // if they picked an int from 1 to 5, give them a new card in that postion
            {
                playersHand[whichCard - 1] = myDeck.GetOneCard();
            }
        }

        private static bool CompareHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            // returns true if player wins.
            int computerHandValue = 0;
            int myHandValue = 0;

            if (Flush(computerHand))
            {
                Console.WriteLine("Computer has flush!");
                Console.Beep();
                return false; // computer wins
            }
            else if (Flush(playersHand))
            {
                Console.Beep(); Console.Beep(); Console.Beep();
                return true; // player wins
            }

            // check for straights
            else
            {
                for (int i = 0; i < computerHand.Length; i++)
                {
                    computerHandValue = computerHandValue + Convert.ToInt16(computerHand[i].cardsRank);
                }
                for (int i = 0; i < playersHand.Length; i++)
                {
                    myHandValue = myHandValue + Convert.ToInt16(playersHand[i].cardsRank);
                }
                if (myHandValue > computerHandValue)  // computer wins on a tie
                {
                    Console.Beep(); Console.Beep(); Console.Beep();
                    return true;
                }
                else
                {
                    Console.Beep();
                    return false;
                }
            }

        }

        private static bool Flush(SuperCard[] PassedInHand)
        {
            bool isAflush = true;
            for (int i = 0; i < PassedInHand.Length - 1; i++)
            {
                if (!(PassedInHand[i].Equals(PassedInHand[i + 1])))
                {
                    isAflush = false;
                }
            }
            return isAflush;
        }

        // is straight? 
        // create new int array, copy from the hand the (cast) rank value into new array
        // sort the new array
        // loop thru new array to makes sure each card n+1 > n by exactly 1

        private static void DisplayHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            Console.WriteLine("DEALER HAND");
            foreach (SuperCard item in computerHand)
            {
                item.Display();
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("YOUR HAND");
            foreach (SuperCard item in playersHand)
            {
                item.Display();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;  // have to reser the colors as the Display methods changed them
            Console.BackgroundColor = ConsoleColor.DarkBlue;
        }
    }
}
