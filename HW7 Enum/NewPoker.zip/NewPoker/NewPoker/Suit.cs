﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    public enum Suit
    {

        Club = 1,  // this order is how we will compare based on suit
        Diamond,
        Heart,
        Spade
    }
}
