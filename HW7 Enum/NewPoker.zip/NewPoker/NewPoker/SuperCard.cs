﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewPoker
{
    public abstract class SuperCard :IComparable<SuperCard>, IEquatable<SuperCard>
    {
        // cardsRank
        public Rank cardsRank { get; set; }
       
        public abstract Suit CardsSuit
        {
            get;
        }

        protected bool _inplay;
        public bool inplay
        {
            get { return _inplay; }
            set { _inplay = value; }
        }

        public abstract void Display();

        public bool Equals(SuperCard otherCard)
        {
            if (otherCard.CardsSuit == this.CardsSuit)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int CompareTo(SuperCard other)
        {

            if (this.CardsSuit != other.CardsSuit)
            {
                switch (this.CardsSuit)
                {
                    case Suit.Spade:
                        return 1;
                        break;
                    case Suit.Heart:
                        if (other.CardsSuit == Suit.Diamond || other.CardsSuit == Suit.Club)
                        {
                            return +1;
                        }
                        else
                        {
                            return -1;
                        }
                        break;
                    case Suit.Diamond:
                        if (other.CardsSuit == Suit.Club)
                        {
                            return +1;
                        }
                        else
                        {
                            return -1;
                        }
                        break;
                    case Suit.Club:
                        return -1;
                        break;
                    default:
                        break;
                }
            }
            else
            // at this point we know we have 2 cards that are the same suit, so sort by value
            {
                int cardVal = (int)this.cardsRank;
                int otherCardVal = (int)other.cardsRank;
                if (cardVal > otherCardVal)
                {
                    return +1;
                }
                else
                {
                    return -1;
                }  // can't be equal, there are no duplicate cards
            }
            return 0; // because Visual Studio thinks I can get here without having done a return.

        }

    }
}
