﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InClassIndexer
{
    class AnimalNoises
    {
        // using parallel arrays
        // this array is used by the indexer to decide which value in the 2nd array to use
        private string[] names = new string[5] { "cat", "dog", "bird", "lion", "cow" };  //array of string names
        private string[] noises = new string[5] { "meow", "woof", "tweet", "roar", "moo" };  //array of string noices

        // define the string indexer
        public string this[string which, int count]
        {
            get
            {
                string returnValue = "";
                for (int i = 0; i < 5; i++)
                {
                    if (which == names[i])
                    {
                        if (count > 0  && count  < 4)
                        {
                            for (int j = 0; j < count; j++)
                            {
                                returnValue = returnValue + " " + noises[i];
                            }
                        }
                        
                        return returnValue;
                    }
                }
                return "problem";
            }
            set
            {
                for (int i = 0; i < 5; i++)
                {
                    if (which == names[i])
                    {
                        noises[i] = value;
                    }
                }
            }
        }

    }
}
