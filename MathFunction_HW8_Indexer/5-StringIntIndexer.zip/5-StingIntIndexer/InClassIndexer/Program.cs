﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InClassIndexer
{
    class Program
    {
        // console program that uses the indexer
        static void Main(string[] args)
        {
            AnimalNoises myNoises = new AnimalNoises();

            // let the user enter an animal name, and use the indexer to return the sound
            bool done = false;
            while (!done)
            {
                Console.Write("enter an animal name or q to quit:  ");
                string animalPicked = Console.ReadLine();
                
                if (animalPicked != "q")
                {
                    Console.WriteLine("how many times should it emit sound?  1, 2, 3");
                    int count = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("That animal makes a sound like: {0}", myNoises[animalPicked, count]);
                    Console.WriteLine();
                }
                else
                {
                    done = true;
                }
                
            }

          
           
            Console.ReadLine();
           
        }
    }
}
